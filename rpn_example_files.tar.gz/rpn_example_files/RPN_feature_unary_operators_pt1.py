import math

OPERATORS = {
    '+': float.__add__,
    '-': float.__sub__,
    '*': float.__mul__,
    '/': float.__div__,
}

# It would be cleaner if I merged this with the OPERATORS dict, and change the
# values to a tuple (function/method, num_operands), but this requires less
# rewriting.
UNARY_OPERATORS = {
    'sin': math.sin,
    'cos': math.cos,
    'tan': math.tan,
    'sqrt': math.sqrt,
}


class RPN(object):
    def __init__(self, expression):
        super(self.__class__, self).__init__()
        self._expression = expression

    def calculate(self):
        stack = []
        for elem in self._expression.split():
            try:
                stack.append(float(elem))
            except ValueError:
                try:
                    operator = OPERATORS.get(elem)
                    term2 = stack.pop()
                    term1 = stack.pop()
                    result = operator(term1, term2)
                    stack.append(result)
                except IndexError:
                    print("Malformed expression: {}".format(self._expression))
                    return
                except TypeError:
                    print("{} is not a valid operator!\nPossible values: {}".format(elem, ', '.join(OPERATORS)))
                    return
        if len(stack) == 1:
            if stack[0].is_integer():
                stack[0] = int(stack[0])
            print("\n>> {}\n".format(stack[0]))
        else:
            print("Malformed expresion: {}".format(self._expression))

    def print_expression(self):
        print(self._expression)
